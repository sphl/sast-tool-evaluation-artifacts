class Foo1():
    pass
