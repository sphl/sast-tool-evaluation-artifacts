class Foo2():
    pass
