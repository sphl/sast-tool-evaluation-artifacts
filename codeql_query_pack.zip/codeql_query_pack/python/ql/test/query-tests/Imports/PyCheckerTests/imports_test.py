
#Import and import from

import test_module2
from test_module2 import func

#Module imports itself
import imports_test

import pkg_ok
import pkg_notok
