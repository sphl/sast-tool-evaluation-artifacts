class Foo5():
    pass
