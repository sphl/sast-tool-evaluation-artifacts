class Foo4():
    pass
