class Bar():
    pass
