
def func():
    pass

