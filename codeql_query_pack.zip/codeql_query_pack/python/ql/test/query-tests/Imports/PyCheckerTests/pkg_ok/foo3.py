class Foo3():
    pass
