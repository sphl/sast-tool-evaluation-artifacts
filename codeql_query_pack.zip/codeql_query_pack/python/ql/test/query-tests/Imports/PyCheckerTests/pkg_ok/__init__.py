import pkg_ok.foo1 as foo1

from pkg_ok import foo2
from pkg_ok.foo3 import Foo3

from . import foo4
from .foo5 import Foo5
