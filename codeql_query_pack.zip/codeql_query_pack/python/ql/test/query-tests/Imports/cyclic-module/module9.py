
x = 1

import main

y = 2