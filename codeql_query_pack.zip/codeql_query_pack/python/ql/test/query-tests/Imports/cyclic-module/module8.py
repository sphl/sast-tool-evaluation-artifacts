import module1

class Foo(object):
    a = module1.a1