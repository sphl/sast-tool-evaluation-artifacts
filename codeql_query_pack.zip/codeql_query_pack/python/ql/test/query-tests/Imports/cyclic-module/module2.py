import module1

# direct use
a2 = module1.a1