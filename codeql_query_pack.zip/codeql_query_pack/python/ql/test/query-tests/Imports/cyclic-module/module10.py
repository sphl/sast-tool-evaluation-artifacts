from typing import TYPE_CHECKING

if False:
    import module1

if TYPE_CHECKING:
    import module1

x = 1
