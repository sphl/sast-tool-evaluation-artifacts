
a = 1
b = 2

if __name__ == '__main__':
    import module9
    print(module9.y)
