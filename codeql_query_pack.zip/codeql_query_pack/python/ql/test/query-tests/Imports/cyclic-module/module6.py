def foo():
    import module7