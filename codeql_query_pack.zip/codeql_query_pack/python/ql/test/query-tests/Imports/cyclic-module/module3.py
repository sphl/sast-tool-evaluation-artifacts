# use via import member
from module1 import a1