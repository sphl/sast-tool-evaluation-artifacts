from bar.foo import foo
from package import baz
p = 1
