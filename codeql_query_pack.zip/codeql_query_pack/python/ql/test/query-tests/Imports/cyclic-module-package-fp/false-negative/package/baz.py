from package import p
from bar.foo import foo
