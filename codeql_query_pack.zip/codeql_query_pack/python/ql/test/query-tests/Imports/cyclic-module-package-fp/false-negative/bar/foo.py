from package import p
foo = 5
