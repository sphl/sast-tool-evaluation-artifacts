import mutable_attr

def f():
    mutable_attr.x = 2
