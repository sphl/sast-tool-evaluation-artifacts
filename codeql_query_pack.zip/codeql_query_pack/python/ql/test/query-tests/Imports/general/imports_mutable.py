from mutable_attr import x, y

def f():
    print(x)
    print(y)
