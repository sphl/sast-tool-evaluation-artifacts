#Fake unittest module

class TestCase(object):
    pass
