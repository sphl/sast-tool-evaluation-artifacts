
class Test:

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_1(self):
        pass

    def test_2(self):
        pass

    def test_3(self):
        pass


import pytest

def test_something(x):
    pass


def with_doctest():
    '''
    >>> 1 + 1
    2

    >>> 1 * 1
    1
    '''

def without_doctest():
   pass