"""
Fake pytest module
"""