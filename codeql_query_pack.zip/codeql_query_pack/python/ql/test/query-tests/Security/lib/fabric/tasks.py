def task(*args, **kwargs):
    pass
