
class ARC4(object):
    name = "RC4"
