class Context(object):
    def run(self, command, **kwargs):
        pass
