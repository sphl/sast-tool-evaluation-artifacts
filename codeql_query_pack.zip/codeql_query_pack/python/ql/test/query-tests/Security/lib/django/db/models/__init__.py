class Model:
    pass
