class RawSQL:
    pass
