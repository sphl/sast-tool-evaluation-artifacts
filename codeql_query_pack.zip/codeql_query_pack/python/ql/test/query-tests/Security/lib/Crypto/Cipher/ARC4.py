
def new(*args):
    pass
