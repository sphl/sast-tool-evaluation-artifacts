
class Cipher(object):
    pass
