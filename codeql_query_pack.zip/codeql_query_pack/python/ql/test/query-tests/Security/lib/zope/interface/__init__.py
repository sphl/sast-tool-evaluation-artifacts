class Interface():
    pass


class implementer:

    def __call__(self, ob):
        ...
        return ob
