# https://docs.djangoproject.com/en/1.11/_modules/django/conf/urls/#url
def url(regex, view, kwargs=None, name=None):
    pass


def patterns(*urls):
    pass
