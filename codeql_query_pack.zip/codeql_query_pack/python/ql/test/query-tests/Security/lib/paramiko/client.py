class SSHClient(object):
    def __init__(self, *args, **kwargs):
        pass

    def set_missing_host_key_policy(self, *args, **kwargs):
        pass

class AutoAddPolicy(object):
    pass

class WarningPolicy(object):
    pass

class RejectPolicy(object):
    pass
