def decodestring(s):
    return None
