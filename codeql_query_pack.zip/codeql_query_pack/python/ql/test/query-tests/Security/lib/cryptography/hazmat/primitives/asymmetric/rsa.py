
def generate_private_key(public_exponent, key_size, backend):
    pass
