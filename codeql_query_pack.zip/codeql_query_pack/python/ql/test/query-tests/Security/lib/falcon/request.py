
class Request(object):
    pass
