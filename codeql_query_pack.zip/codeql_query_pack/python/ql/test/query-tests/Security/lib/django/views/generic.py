# For django 1.x
class View:
    pass
