class Request(object):
    pass
