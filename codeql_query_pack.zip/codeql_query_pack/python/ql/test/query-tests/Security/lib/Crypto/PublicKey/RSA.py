def generate(bits):
    pass
