from .context import Context
from .tasks import task

def run(command, **kwargs):
    pass

def sudo(command, **kwargs):
    pass
