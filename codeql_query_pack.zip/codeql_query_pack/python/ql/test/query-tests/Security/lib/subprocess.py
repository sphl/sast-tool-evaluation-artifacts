def Popen(*args, **kwargs):
    return None