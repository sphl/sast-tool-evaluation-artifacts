class View(object):
    pass


class MethodView(object):
    pass
