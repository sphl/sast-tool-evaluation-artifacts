class HttpRequest(object):
    pass
