def load(s):
    pass
