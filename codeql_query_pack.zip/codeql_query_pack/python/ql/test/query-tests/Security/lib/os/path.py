def join(a, *b):
    return a + "/" + "/".join(b)

def normpath(x):
    return x
