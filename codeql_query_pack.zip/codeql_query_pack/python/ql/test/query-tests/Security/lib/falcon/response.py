

class Response(object):
    pass
