
def generate_private_key(key_size, backend):
    pass

