class Resource(object):
    pass
