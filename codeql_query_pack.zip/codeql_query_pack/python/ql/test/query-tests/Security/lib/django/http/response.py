class HttpResponse(object):
    pass
