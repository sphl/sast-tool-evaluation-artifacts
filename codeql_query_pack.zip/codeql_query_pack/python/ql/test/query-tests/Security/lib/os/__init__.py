def system(cmd, *args, **kwargs):
    return None

def popen(cmd, *args, **kwargs):
    return None

def chmod(path, mode):
    pass

def open(path, flags, mode):
    pass

def tempnam(*args):
    pass

def tmpnam(*args):
    pass
