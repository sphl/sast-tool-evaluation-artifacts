# For django 2.x and 3.x
class View:
    pass
