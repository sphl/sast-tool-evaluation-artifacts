# https://docs.pylonsproject.org/projects/pyramid/en/1.10-branch/_modules/pyramid/view.html#view_config
class view_config(object):
    def __init__(self, **settings):
        pass

    def __call__(self, wrapped):
        pass
