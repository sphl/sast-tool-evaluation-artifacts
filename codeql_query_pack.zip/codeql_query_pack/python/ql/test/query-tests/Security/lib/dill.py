def loads(*args, **kwargs):
    return None
