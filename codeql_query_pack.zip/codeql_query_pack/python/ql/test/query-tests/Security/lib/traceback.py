def format_exc():
    return None