
class LocalProxy(object):
    pass

request = LocalProxy()
current_app = LocalProxy()
