#Fake pytest module for testing.

def fixture(param):
    return param
