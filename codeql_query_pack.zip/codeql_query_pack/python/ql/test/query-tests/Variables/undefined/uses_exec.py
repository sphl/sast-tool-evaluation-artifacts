from other import setup

exec('x/_version.py')

setup(
    name='x',
    version=__version__
    )
