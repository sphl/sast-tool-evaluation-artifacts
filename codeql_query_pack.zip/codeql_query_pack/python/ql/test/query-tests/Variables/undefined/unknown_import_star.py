__all__ = ["foo"]

from unknown_module import *
