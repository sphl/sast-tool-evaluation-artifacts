#If we use the standard import form the test runner will import quite a lot of the standard library
os = __import__("os")