
from who_knows_what import *

#Anything could be imported from who_knows_what
#So we have to assume the following could be defined
a
b
c
