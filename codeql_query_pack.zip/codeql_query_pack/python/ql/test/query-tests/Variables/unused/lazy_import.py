
from clever_lazy_module_thing import range

#OK iteration over range
def OK4(n):
    for i in range(n):
        print("x")
