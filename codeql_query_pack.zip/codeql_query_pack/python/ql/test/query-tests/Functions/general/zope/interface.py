#Fake zope.interface Module

class InterfaceClass(type):
    pass

Interface = InterfaceClass()
