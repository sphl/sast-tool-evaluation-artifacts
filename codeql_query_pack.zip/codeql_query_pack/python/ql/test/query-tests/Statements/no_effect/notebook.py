
# This test is for IPython/Jupyter notebooks which can legitimately include bare expressions at the end of each code-cell.

# <nbformat>3.0</nbformat>

# <codecell>
y = 1 + 1
y

# <codecell>
z = 2 * 2
z

# <codecell>
y











