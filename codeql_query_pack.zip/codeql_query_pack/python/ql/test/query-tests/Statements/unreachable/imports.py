
try:
    import fcntl
except ImportError:
    pass


try:
    import __builtin__
except ImportError:
    import builtins as __builtin__

