
a = 1
b = 2
c = 3

#Explicit relative import
from .helper import d

#Explicit relative import
from .helper import g

from .assistant import f

from . import helper
