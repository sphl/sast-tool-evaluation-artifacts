__all__ = [ 'p', 'q', 'r']

p = 'p'
q = 'q'
r = 'r'
s = 's'
