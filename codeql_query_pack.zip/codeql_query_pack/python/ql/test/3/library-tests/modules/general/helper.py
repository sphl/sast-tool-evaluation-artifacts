class Wrong: pass

class CorrectIn3(object):
    pass

d = Wrong()
