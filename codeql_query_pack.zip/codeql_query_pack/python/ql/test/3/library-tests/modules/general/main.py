import package
import helper
import package.assistant
#We expect that 'a' below will be 1 not a module.
from confused_elements import a

import sys