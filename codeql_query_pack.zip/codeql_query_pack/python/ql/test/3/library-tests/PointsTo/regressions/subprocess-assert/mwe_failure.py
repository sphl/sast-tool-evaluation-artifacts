import subprocess
assert subprocess.call(['run-backup']) == 0

class TestCase:
    pass

class MyTest(TestCase):
    pass

# found by /home/rasmus/code/ql/python/ql/test/query-tests/Statements/asserts/AssertLiteralConstant.qlref
