
import sys

os_test = sys.platform == "linux"
version_test = sys.version_info < (3,)
