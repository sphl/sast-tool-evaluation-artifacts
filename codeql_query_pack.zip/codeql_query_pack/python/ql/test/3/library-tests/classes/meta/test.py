
class Meta(type):
    pass

class HasMeta(object, metaclass=Meta):
    pass