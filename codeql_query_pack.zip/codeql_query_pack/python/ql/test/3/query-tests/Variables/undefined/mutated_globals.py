

__all__ = [ "a", "b" ]

globals().update({'a':1, 'b':2})
