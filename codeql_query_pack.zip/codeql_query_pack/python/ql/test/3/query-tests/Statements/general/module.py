#Top level prints in modules are bad
print ("Side effect on import")