
def format_starred(t):
    return "%x %x %x" % (0, *t)

def ascii(a, b):
    return "%a %x" % (a, b)