dictionary = {1:"a", 2:"b", 2:"c"}
print dictionary[2]