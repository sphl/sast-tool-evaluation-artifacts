
def format_as_tuple_incorrect(args):
    return "%t" % args

def format_as_tuple_correct(args):
    return "%r" % (args,)
