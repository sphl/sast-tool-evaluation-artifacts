def surplus_argument():
    the_format = "{} {}" # Used to be "{} {} {}"
    return the_format.format(1, 2, 3)
