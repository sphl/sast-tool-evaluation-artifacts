def surplus_argument():
    the_format = "{spam} {eggs}" # Used to be "{spam} {eggs} {chips}"
    return the_format.format(spam = "spam", eggs="eggs", chips="chips")
