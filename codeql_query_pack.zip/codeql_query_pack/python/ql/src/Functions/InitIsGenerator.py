class InitIsGenerator(object):
    def __init__(self, i):
        yield i