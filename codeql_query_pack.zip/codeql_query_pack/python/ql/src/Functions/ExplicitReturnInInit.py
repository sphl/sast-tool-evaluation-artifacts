class ExplicitReturnInInit(object):
    def __init__(self, i):
        self.i = i
        return self