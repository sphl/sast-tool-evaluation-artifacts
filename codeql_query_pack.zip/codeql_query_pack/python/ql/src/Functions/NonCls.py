class Entry(object):
    @classmethod
    def make(klass):
        return Entry()
