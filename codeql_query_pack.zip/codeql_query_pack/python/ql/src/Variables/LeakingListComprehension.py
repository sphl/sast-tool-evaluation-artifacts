
def two_or_three():
    x = 3
    [0 for x in range(3)]
    return x # Will return 2 in Python 2 and 3 in Python 3.

print(two_or_three())