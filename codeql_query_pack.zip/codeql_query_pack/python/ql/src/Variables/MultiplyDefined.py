x = 42
x = 12
print x