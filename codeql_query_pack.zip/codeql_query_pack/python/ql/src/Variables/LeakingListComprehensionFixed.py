
def just_three():
    x = 3
    [0 for y in range(3)]
    return x # Will return always return 3.

print(just_three())