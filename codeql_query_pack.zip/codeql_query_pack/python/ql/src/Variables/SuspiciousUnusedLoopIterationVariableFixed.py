
#
def test():
    for t in [TypeA, TypeB]:
        x = t
        run_test(x)
