__all__ = ['spamm', 'troll', 'paywall']

def spam(): return 'Spam'
def troll(): return 'Troll'
def paywall(): return 'Pay wall'
