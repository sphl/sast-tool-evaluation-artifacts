

def raise_tuple():
    ex = Exception, "Important diagnostic information"
    raise ex
