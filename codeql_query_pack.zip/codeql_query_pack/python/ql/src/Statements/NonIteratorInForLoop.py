

def illegal_for_loop(seq = None):
    for x in seq:
        print (x)

