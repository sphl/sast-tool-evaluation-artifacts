import math

def my_div(x, y):
    return math.floor(x / y)
    remainder = x - math.floor(x / y) * y
